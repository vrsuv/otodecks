/*
  ==============================================================================

    PlaylistComponent.cpp
    Created: 6 Feb 2022 8:07:49pm
    Author:  Rajasuvedha Vivekanandan

  ==============================================================================
*/

#include <JuceHeader.h>
#include "PlaylistComponent.h"

#include <vector>
#include <string>
#include <fstream>


//==============================================================================
PlaylistComponent::PlaylistComponent(DJAudioPlayer* _player1,
                                     DJAudioPlayer* _player2,
                                     juce::AudioFormatManager& formatManager,
                                     WaveformDisplay* _waveformDisplay1,
                                     WaveformDisplay* _waveformDisplay2)
                                        :player1(_player1),
                                        player2(_player2),
                                        formatManager(formatManager),
                                        waveformDisplay1(_waveformDisplay1),
                                        waveformDisplay2(_waveformDisplay2)
{
    // In your constructor, you should add any child components, and
    // initialise any special settings that your component needs.
    
    // load playlist button
    addAndMakeVisible(loadPlaylistButton);
    loadPlaylistButton.addListener(this);

    // table headers
    tableComponent.getHeader().addColumn("Track title", 1, 500);
    tableComponent.getHeader().addColumn("Duration (secs)", 2, 135);
    tableComponent.getHeader().addColumn("Deck 1", 3, 150);
    tableComponent.getHeader().addColumn("Deck 2", 4, 150);
    tableComponent.getHeader().addColumn("Remove", 5, 65);

    // table component
    tableComponent.setModel(this);
    addAndMakeVisible(tableComponent);
    
    // search bar
    addAndMakeVisible(searchBar);
    searchBar.onReturnKey = [this] {searchResult(searchBar.getText()); };
    tableComponent.setMultipleSelectionEnabled(true);
}

PlaylistComponent::~PlaylistComponent()
{
}

void PlaylistComponent::paint (juce::Graphics& g)
{
    /* This demo code just fills the component's background and
       draws some placeholder text to get you started.

       You should replace everything in this method with your own
       drawing code..
    */

    // clear the background
    g.fillAll (getLookAndFeel().findColour (juce::ResizableWindow::backgroundColourId));

    // draw an outline around the component
    g.setColour (juce::Colours::grey);
    g.drawRect (getLocalBounds(), 1);

    // draw some placeholder text
    g.setColour (juce::Colours::white);
    g.setFont (14.0f);
    g.drawText ("PlaylistComponent",
                getLocalBounds(),
                juce::Justification::centred,
                true);
    
    // draw label for search bar
    g.drawText("Search:",
               getWidth() - getWidth()/3 - 100,
               10,
               150,
               20,
               juce::Justification::centred);
}

void PlaylistComponent::resized()
{
    // This method is where you should set the bounds of any child
    // components that your component contains..

    // location and size of load button
    loadPlaylistButton.setBounds(0, 0, getWidth()/4, getHeight()/8);
    
    // location and size of search bar
    searchBar.setBounds(getWidth() - getWidth()/3, 0, getWidth() /3 , getHeight() / 9);
    
    // location and size of playlist table
    tableComponent.setBounds(0, getHeight()/8, getWidth(), getHeight());
    
}

int PlaylistComponent::getNumRows()
{
    return trackTitles.size();
}

// function to set colour of row when row is clicked/not clicked
void PlaylistComponent::paintRowBackground (juce::Graphics & g,
                                             int rowNumber,
                                             int width,
                                             int height,
                                             bool rowIsSelected)
{
    // colour of row when row is selected
    if (rowIsSelected)
    {
        g.fillAll(juce::Colours::orange);
    }
    
    // colour of row when row is not selected
    else
    {
        g.fillAll(juce::Colours::grey);
    }
}

// function to draw each cell
void PlaylistComponent::paintCell (juce::Graphics & g,
                                    int rowNumber,
                                    int columnId,
                                    int width,
                                    int height,
                                    bool rowIsSelected)
{
    // first column
    if(columnId == 1)
    {
        g.drawText(trackTitles[rowNumber],
                   2,
                   0,
                   width - 4,
                   height,
                   juce::Justification::centredLeft,
                   true);
    }
    
    // second column
    if(columnId == 2)
    {
        g.drawText(std::to_string(trackDurations[rowNumber]),
                   2,
                   0,
                   width - 4,
                   height,
                   juce::Justification::centredLeft,
                   true);
    }
    
}

// function to implement any special components in table
juce::Component* PlaylistComponent::refreshComponentForCell (int rowNumber,
                                                            int columnId,
                                                            bool isRowSelected,
                                                            Component *existingComponentToUpdate)
{
    // button to load track to deck 1
    if (columnId == 3)
    {
        if(existingComponentToUpdate == nullptr)
        {
            juce::TextButton* btn = new juce::TextButton("Add to Deck 1");
            juce::String id{std::to_string(columnId)+std::to_string(rowNumber)};
            btn->setComponentID(id);
            btn->addListener(this);
            existingComponentToUpdate = btn;
        }
    }
    
    // button to load track to deck 2
    else if (columnId == 4)
    {
        if(existingComponentToUpdate == nullptr)
        {
            juce::TextButton* btn = new juce::TextButton("Add to Deck 2");
            juce::String id{std::to_string(columnId)+std::to_string(rowNumber)};
            btn->setComponentID(id);
            btn->addListener(this);
            existingComponentToUpdate = btn;
        }
    }
    
    // button to remove track from playlist
    else if (columnId == 5)
    {
        if (existingComponentToUpdate == nullptr)
        {
            juce::TextButton* btn = new juce::TextButton{"Remove"};
            juce::String id{std::to_string(columnId)+std::to_string(rowNumber)};
            btn->setComponentID(id);
            btn->addListener(this);
            existingComponentToUpdate = btn;
        }
    }

    return existingComponentToUpdate;
}

// function to call when button is clicked
void PlaylistComponent::buttonClicked(juce::Button* button)
{
    // load playlist
    if (button == &loadPlaylistButton)
    {
        juce::FileChooser chooser{ "Select a file..." };
        if (chooser.browseForFileToOpen())
        {
            getTracks(chooser.getResult());
            getDuration(juce::URL{chooser.getURLResult()});
        }
    }
    
    else
    {
        // converting button id to substrings
        std::string idString = button->getComponentID().toStdString();
        int id = std::stoi(idString.substr(1));
        
        // load track to deck 1
        if(idString.at(0) == '3')
        {
            std::cout << "Load to deck 1 button clicked for " << trackTitles[id] << std::endl;
            
            player1->loadURL(juce::URL{trackURLs[id]});
            waveformDisplay1->loadURL(juce::URL{trackURLs[id]});
        }

        // load track to deck 2
        else if(idString.at(0) == '4')
        {
            std::cout << "Load to deck 2 button clicked for " << trackTitles[id] << std::endl;
            
            player2->loadURL(juce::URL{trackURLs[id]});
            waveformDisplay2->loadURL(juce::URL{trackURLs[id]});
        }

        // remove track from playlist
        else if(idString.at(0) == '5')
        {
            if (id <= trackTitles.size() && id <= trackURLs.size())
            {
                trackTitles.erase(trackTitles.begin() + id);
                trackURLs.erase(trackURLs.begin() + id);
                std::cout << "Track deleted: " << trackTitles[id] << std::endl;
                tableComponent.updateContent();
            }
        }
    }
}

// function to push track names and URLs into respective arrays
void PlaylistComponent::getTracks(juce::Array<juce::File> tracksFile)
{
    for (int i = 0; i < tracksFile.size(); i++)
    {
        trackTitles.push_back(juce::File{tracksFile[i]}.getFileNameWithoutExtension());
        trackURLs.push_back(juce::URL{juce::File{tracksFile[i]}});
    }
    tableComponent.updateContent();
}

// function called when user is going to drag and drop file into the app
bool PlaylistComponent::isInterestedInFileDrag (const juce::StringArray &files)
{
    std::cout << "PlaylistComponent::isInterestedInFileDrag" << std::endl;
    return true;
}

// function to push track names, URLs and durations into respective arrays when files dropped
void PlaylistComponent::filesDropped (const juce::StringArray &files, int x, int y)
{
    if (files.size() >= 1)
    {
        for (int i = 0; i < files.size(); i++)
        {
            trackTitles.push_back(juce::File{files[i]}.getFileNameWithoutExtension());
            trackURLs.push_back(juce::URL{juce::File{files[i]}});
            getDuration(juce::URL{juce::File{files[i]}});
            
            juce::String urlLink = juce::URL{juce::File{files[i]}}.toString(false);
            std::cout << urlLink << std::endl;
        }
        tableComponent.updateContent();
    }
}

// function to get duration and push into trackDurations array
void PlaylistComponent::getDuration(juce::URL audioURL)
{
    auto* reader = formatManager.createReaderFor(audioURL.createInputStream(false));
    if(reader != nullptr) // good file!
    {
        std::unique_ptr<juce::AudioFormatReaderSource> newSource (new juce::AudioFormatReaderSource (reader, true));

        transportSource.setSource(newSource.get(), 0, nullptr, reader->sampleRate);
        readerSource.reset(newSource.release());
        
        int duration;
        duration = transportSource.getLengthInSeconds();
        trackDurations.push_back(duration);
    }
}

// function to highlight rows when search input contains track name
void PlaylistComponent::searchResult(juce::String searchInput)
{
    if (searchInput == "")
    {
        tableComponent.deselectAllRows();
    }
    else
    {
        for (int i = 0; i < trackTitles.size(); i++)
        {
            if (trackTitles[i].contains(searchInput))
            {
                tableComponent.selectRow(i);
            }
        }
    }
}

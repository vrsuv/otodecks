/*
  ==============================================================================

    DeckGUI.cpp
    Created: 5 Feb 2022 11:38:00am
    Author:  Rajasuvedha Vivekanandan

  ==============================================================================
*/

#include <JuceHeader.h>
#include "DeckGUI.h"

//==============================================================================
DeckGUI::DeckGUI(DJAudioPlayer* _player,
                    WaveformDisplay* _waveformDisplay)
                    :player(_player),
                    waveformDisplay(_waveformDisplay)
{
    
    addAndMakeVisible(playButton);
    addAndMakeVisible(stopButton);
    addAndMakeVisible(restartButton);
    
    addAndMakeVisible(volSlider);
    addAndMakeVisible(speedSlider);
    addAndMakeVisible(posSlider);
    
    playButton.addListener(this);
    stopButton.addListener(this);
    restartButton.addListener(this);
    
    volSlider.addListener(this);
    speedSlider.addListener(this);
    posSlider.addListener(this);
    
    volSlider.setRange(0, 1);
    speedSlider.setRange(0.9, 2);
    posSlider.setRange(0, 1);
    
    startTimer(100);
}

DeckGUI::~DeckGUI()
{
    stopTimer();
}

void DeckGUI::paint (juce::Graphics& g)
{
    /* This demo code just fills the component's background and
       draws some placeholder text to get you started.

       You should replace everything in this method with your own
       drawing code..
    */

    g.fillAll (getLookAndFeel().findColour (juce::ResizableWindow::backgroundColourId));   // clear the background

    // borderline design
    g.setColour (juce::Colours::grey);
    g.drawRect (getLocalBounds(), 1);   // draw an outline around the component

    g.setColour (juce::Colours::white);
    g.setFont (14.0f);

    // draw some placeholder text
    g.drawText ("DeckGUI",
                getLocalBounds(),
                juce::Justification::bottom,
                true);

    // labels for each slider
    g.setColour (juce::Colours::white);
    g.setFont (15.0f);
    g.drawText("Speed", getWidth()/6, getHeight() - 30, 90, 20, juce::Justification::centred);
    g.drawText("Volume", getWidth()/3 + 20, getHeight() - 30, 90, 20, juce::Justification::right);
    g.drawText("Position", 2*getWidth()/3, getHeight() - 30, 90, 20, juce::Justification::centred);
    
    // set slider style
    // speed slider style
    speedSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 20);
    speedSlider.setSliderStyle(juce::Slider::LinearVertical);
    
    // volume slider style
    volSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 20);
    volSlider.setSliderStyle(juce::Slider::RotaryHorizontalDrag);
    
    // position slider style
    posSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 20);
    posSlider.setSliderStyle(juce::Slider::LinearVertical);

}

void DeckGUI::resized()
{
    double rowH = getHeight() / 8;
    double colW = getWidth() / 6;
    
    stopButton.setBounds(colW, rowH*1.7, colW, rowH);
    playButton.setBounds(colW*2.5, rowH*1.7, colW, rowH);
    restartButton.setBounds(colW*4, rowH*1.7, colW, rowH);
    
    speedSlider.setBounds(colW, rowH*3, colW, rowH*4.3);
    volSlider.setBounds(colW*2, rowH*3, colW*2, rowH*4.3);
    posSlider.setBounds(colW*4, rowH*3, colW, rowH*4.3);
}

void DeckGUI::buttonClicked(juce::Button* button)
{
    if (button == &playButton)
    {
        std::cout << "Play button was clicked " << std::endl;
        player->start();
    }
    if (button == &stopButton)
    {
        std::cout << "Stop button was clicked " << std::endl;
        player->stop();
    }
    if (button == &restartButton)
    {
        std::cout << "Restart button was clicked " << std::endl;
        player->restart();
    }
}

void DeckGUI::sliderValueChanged(juce::Slider *slider)
{
    if(slider == &volSlider)
    {
        player->setGain(slider->getValue());
    }
    
    if(slider == &speedSlider)
    {
        player->setSpeed(slider->getValue());
    }
    
    if(slider == &posSlider)
    {
        player->setPositionRelative(slider->getValue());
    }
}

bool DeckGUI::isInterestedInFileDrag (const juce::StringArray &files)
{
    std::cout << "DeckGUI::isInterestedInFileDrag" << std::endl;
    return true;
}

void DeckGUI::filesDropped (const juce::StringArray &files, int x, int y)
{
    std::cout << "FileDropped" << std::endl;
    if(files.size() == 1)
    {
        player->loadURL(juce::URL{juce::File{files[0]}});
        waveformDisplay->loadURL(juce::URL{juce::File{files[0]}});
    }
}
 
void DeckGUI::timerCallback()
{
    waveformDisplay->setPositionRelative(player->getPositionRelative());
}

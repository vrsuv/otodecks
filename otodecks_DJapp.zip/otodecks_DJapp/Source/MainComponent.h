#pragma once

#include <JuceHeader.h>
#include "DJAudioPlayer.h"
#include "DeckGUI.h"
#include "PlaylistComponent.h"

//==============================================================================
/*
    This component lives inside our window, and this is where you should put all
    your controls and content.
*/
class MainComponent  : public juce::AudioAppComponent
{
public:
    //==============================================================================
    MainComponent();
    ~MainComponent() override;

    //==============================================================================
    void prepareToPlay (int samplesPerBlockExpected, double sampleRate) override;
    void getNextAudioBlock (const juce::AudioSourceChannelInfo& bufferToFill) override;
    void releaseResources() override;

    //==============================================================================
    void paint (juce::Graphics& g) override;
    void resized() override;
    
    
    

private:
    
    juce::AudioFormatManager formatManager;
    juce::AudioThumbnailCache thumbCache{100};
    
    DJAudioPlayer player1{formatManager};
    DeckGUI deckGUI1{&player1, &waveformDisplay1};
    
    DJAudioPlayer player2{formatManager};
    DeckGUI deckGUI2{&player2, &waveformDisplay2};
    
    juce::MixerAudioSource mixerSource;
    
    WaveformDisplay waveformDisplay1{ formatManager, thumbCache };
    WaveformDisplay waveformDisplay2{ formatManager, thumbCache };
    
    PlaylistComponent playlistComponent{&player1,
                                        &player2,
                                        formatManager,
                                        &waveformDisplay1,
                                        &waveformDisplay2};
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MainComponent)
};

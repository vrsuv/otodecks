/*
  ==============================================================================

    PlaylistComponent.h
    Created: 6 Feb 2022 8:07:49pm
    Author:  Rajasuvedha Vivekanandan

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "DJAudioPlayer.h"
#include "DeckGUI.h"
#include "WaveformDisplay.h"

#include <vector>
#include <string>
#include <fstream>

//==============================================================================
/*
*/
class PlaylistComponent  :  public juce::Component,
                            public juce::TableListBoxModel,
                            public juce::Button::Listener,
                            public juce::FileDragAndDropTarget
{
public:
    PlaylistComponent(DJAudioPlayer* _player1,
                      DJAudioPlayer* _player2,
                      juce::AudioFormatManager& formatManager,
                      WaveformDisplay* _waveformDisplay1,
                      WaveformDisplay* _waveformDisplay2);
    
    ~PlaylistComponent() override;

    void paint (juce::Graphics&) override;
    void resized() override;

    int getNumRows() override;

    void paintRowBackground (juce::Graphics &,
                             int rowNumber,
                             int width,
                             int height,
                             bool rowIsSelected) override;

    void paintCell (juce::Graphics &,
                    int rowNumber,
                    int columnId,
                    int width,
                    int height,
                    bool rowIsSelected) override;

    juce::Component* refreshComponentForCell (int rowNumber,
                                                int columnId,
                                                bool isRowSelected,
                                                Component *existingComponentToUpdate) override;

    void buttonClicked(juce::Button *) override;
    
    bool isInterestedInFileDrag(const juce::StringArray &files) override;
    void filesDropped(const juce::StringArray &files, int x, int y);
    
    void loadURL(juce::URL audioURL);


private:

    juce::TableListBox tableComponent;
    
    std::vector<juce::String> trackTitles;
    std::vector<juce::URL> trackURLs;
    std::vector<int> trackDurations;

    juce::TextEditor searchBar;
    void searchResult(juce::String searchInput);
    
    void getTracks(juce::Array<juce::File> tracksFile);
    
    juce::TextButton loadPlaylistButton{"LOAD playlist"};
    
    void getDuration(juce::URL audioURL);

    DJAudioPlayer* player1;
    DJAudioPlayer* player2;
    WaveformDisplay* waveformDisplay1;
    WaveformDisplay* waveformDisplay2;
    
    juce::AudioFormatManager& formatManager;
    std::unique_ptr<juce::AudioFormatReaderSource> readerSource;
    juce::AudioTransportSource transportSource;
    juce::ResamplingAudioSource resampleSource{&transportSource, false, 2};
    

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PlaylistComponent)
};
